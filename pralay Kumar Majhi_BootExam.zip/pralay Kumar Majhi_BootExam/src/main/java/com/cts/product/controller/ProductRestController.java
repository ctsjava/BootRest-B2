package com.cts.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.product.entity.Student;
import com.cts.product.dao.AdmissionDao;

@RestController
@CrossOrigin
@RequestMapping("api/students")
public class ProductRestController {
	
	@Autowired
	private AdmissionDao ad;
	
	@GetMapping
	public ResponseEntity<List<Student>> listAll(){
		return ResponseEntity.ok(ad.findAll());
	}
	
	@PostMapping
	public ResponseEntity<?> saveStudent(@RequestBody Student student) {
		
		return ResponseEntity.ok(ad.save(student));
		
	}
	
	@PutMapping
	public ResponseEntity<?> updateProduct(@RequestBody Student student){
		
		Student s=ad.findById(student.getAdmissionId()).orElse(null);
		
		if(s!=null) {
			return ResponseEntity.ok(ad.save(student));
		}
		
		return ResponseEntity.badRequest().body(HttpStatus.NO_CONTENT);
		
	}
	
	@DeleteMapping("/{admissionId}")
	public ResponseEntity<?> deleteProduct(@PathVariable("admissionId")int admissionId) {
		
		ad.deleteById(admissionId);
		
		
		return ResponseEntity.ok(HttpStatus.valueOf(204));
		
	}
	
	
	

}