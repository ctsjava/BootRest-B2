package com.cts.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootExamApplication.class, args);
	}

}
