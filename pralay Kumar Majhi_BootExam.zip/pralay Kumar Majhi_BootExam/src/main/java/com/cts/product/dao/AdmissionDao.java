package com.cts.product.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.product.entity.Student;

@Repository
public interface AdmissionDao extends JpaRepository<Student, Integer>{

}
