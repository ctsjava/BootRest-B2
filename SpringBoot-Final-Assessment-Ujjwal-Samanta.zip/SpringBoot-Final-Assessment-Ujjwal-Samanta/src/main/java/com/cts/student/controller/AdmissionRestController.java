package com.cts.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.student.entities.Admission;
import com.cts.student.entities.Student;
import com.cts.student.service.StudentService;

@RestController
@CrossOrigin
@RequestMapping("api/admissions")
public class AdmissionRestController {
	
	@Autowired
	private StudentService studentService;
	
	@GetMapping
	public ResponseEntity<List<Student>> findAllActor(){
		
		return ResponseEntity.ok(studentService.findAll());
		
	}
	
	@PostMapping
	public ResponseEntity<?> saveStudent(@RequestBody Student student) {
		return ResponseEntity.ok(studentService.saveStudent(student));
	}
	
	@PutMapping
	public ResponseEntity<?> updateStudent(@RequestBody Student student) {
		Student tempStudent=studentService.findStudentById(student.getAdmissionId());
		if (tempStudent!=null){
			return ResponseEntity.ok(studentService.saveStudent(student));	
		}
		return ResponseEntity.ok().body(HttpStatus.NO_CONTENT);
		
	}
		
	@DeleteMapping("/{studentId}")
	public ResponseEntity<?> deleteStudent(@PathVariable("studentId")int studentId) {
		Student student=studentService.findStudentById(studentId);
		
		if (student!=null){
			studentService.deleteStudentById(studentId);
			return ResponseEntity.ok().body(HttpStatus.NO_CONTENT);
		}
		
		return ResponseEntity.ok().body(HttpStatus.NO_CONTENT);
		
	}
	
	
	
}
