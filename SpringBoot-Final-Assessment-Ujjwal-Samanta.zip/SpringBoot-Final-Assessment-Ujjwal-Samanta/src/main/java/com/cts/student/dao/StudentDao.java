package com.cts.student.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.student.entities.Admission;
import com.cts.student.entities.Student;

public interface StudentDao extends JpaRepository<Student, Integer>{

	
}