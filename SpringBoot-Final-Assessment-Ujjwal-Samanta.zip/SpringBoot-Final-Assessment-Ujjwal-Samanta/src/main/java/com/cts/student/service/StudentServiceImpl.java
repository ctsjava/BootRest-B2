package com.cts.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.student.dao.StudentDao;
import com.cts.student.entities.Admission;
import com.cts.student.entities.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao studentDao;

	
	@Transactional
	public Student saveStudent(Student student) {
		return studentDao.save(student);
	}

	@Transactional
	public List<Student> findAll() {
		return studentDao.findAll();
	}

	
	@Transactional
	public Student updateStudent(Student student) {
		return studentDao.save(student);
	}
	
	@Transactional
	public void deleteStudentById(int studentId) {
		studentDao.deleteById(studentId);
	}

	@Override
	public Student findStudentById(int studentId) {
		return studentDao.findById(studentId).orElse(null);
		}

		
}