package com.cts.student.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.cts.student.entities.Admission;
import com.cts.student.entities.Student;

public interface StudentService {

	Student saveStudent(Student student);

	List<Student> findAll();

	Student updateStudent(Student student);
	
	void deleteStudentById(int studentId);
	
	Student findStudentById(int studentId);

}